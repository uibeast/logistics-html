$(function() {
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop(true, true).fadeIn("fast");
            $(this).toggleClass('open');
            $('b', this).toggleClass("caret caret-up");
        },
        function() {
            $('.dropdown-menu', this).stop(true, true).fadeOut("fast");
            $(this).toggleClass('open');
            $('b', this).toggleClass("caret caret-up");
        });
});

$(function() {
    $('.carouselId').owlCarousel({
        loop: true,
        nav: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.container-fluid .custom-nav',
        items: 1,
        margin: 0,
        autoplay: true,
        stagePadding: 0,
        smartSpeed: 450,
        autoplayTimeout: 85000,
    });
});

// Counter 
jQuery('.statistic-counter').counterUp({
    delay: 30,
    time: 2000
});